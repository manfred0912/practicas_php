<!DOCTYPE html>

<html>

<body>
	<div align="center" style="background-color: lightgray">
    <form action="mostrar.php" method="post">
    	<h1>Bienvenido</h1>
    	<p>Ingresa tu usuario y un color</p>
        Usuario<input type="text" name="usuario"><br>
        Color<input type="color" name="color">
         <br><br>
         <input type="submit" name="submit" value="Submit">
        <input type="submit" name="actualizar"  value="Actualizar">
        <input type="submit" name="borrar" value="Borrar cookie">
        <input type="submit" name="show" value="Mostrar cookie">
   
    </form>
  
    
    </div>

</body>
</html>